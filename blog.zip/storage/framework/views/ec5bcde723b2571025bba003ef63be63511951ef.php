<html>

<head>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sideNav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/react-quill@1.3.3/dist/quill.snow.css">
</head>

<body>

<div id="root">

</div>


<script type="text/javascript" src="<?php echo e(asset('js/Main.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\Admin\blog\resources\views\index.blade.php ENDPATH**/ ?>